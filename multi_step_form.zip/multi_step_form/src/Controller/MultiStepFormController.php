<?php

namespace Drupal\multi_step_form\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\JsonResponse;

class MultiStepFormController extends ControllerBase {

  /**
   * Autocomplete callback for country field.
   *
   * @param string $string
   *   The search string.
   *
   * @return \Symfony\Component\HttpFoundation\JsonResponse
   *   The JSON response with country suggestions.
   */
  public function autocompleteCountry($string) {
    $matches = [];
    $countries = $this->getCountryList(); // Retrieve country list from a method or configuration

    foreach ($countries as $country) {
      if (stripos($country, $string) !== FALSE) {
        $matches[] = ['value' => $country, 'label' => $country];
      }
    }

    return new JsonResponse($matches);
  }

  /**
   * Retrieves a list of countries.
   *
   * @return array
   *   An array of country names.
   */
  private function getCountryList() {
    // Replace this with actual country data or a service call to get the list.
    return [
      'United States',
      'Canada',
      'Mexico',
      'United Kingdom',
      'Germany',
      'France',
      'Australia',
      'Japan',
      'China',
      'India',
      // Add more countries as needed
    ];
  }
}
