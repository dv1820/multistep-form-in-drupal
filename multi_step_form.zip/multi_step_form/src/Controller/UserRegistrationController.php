<?php
namespace Drupal\multi_step_form\Controller;

use Drupal\Core\Controller\ControllerBase;
use Symfony\Component\HttpFoundation\Request;

class UserRegistrationController extends ControllerBase {

  public function listRegistrations(Request $request) {
    $limit = 5;  // Number of items per page
    $page = $request->query->get('page', 0);  // Current page number from query parameter

    // Entity query to fetch nodes of type 'user_registration'
    $query = \Drupal::entityQuery('node')
      ->condition('type', 'user_registration')
      ->accessCheck(TRUE)  // Ensure access checking is enabled
      ->range($page * $limit, $limit)
      ->sort('created', 'DESC');

    $nids = $query->execute();

    // Load nodes based on NIDs
    $nodes = \Drupal\node\Entity\Node::loadMultiple($nids);

    // Get the total number of records for pagination
    $total = \Drupal::entityQuery('node')
      ->condition('type', 'user_registration')
      ->accessCheck(TRUE)  // Ensure access checking is enabled
      ->count()
      ->execute();

    return [
      '#theme' => 'user_registration_list',
      '#registrations' => $nodes,
      '#pager' => [
        'total' => $total,
        'limit' => $limit,
        'current' => $page,
      ],
    ];
  }
}
