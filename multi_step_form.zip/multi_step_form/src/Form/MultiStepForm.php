<?php

namespace Drupal\multi_step_form\Form;

use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Messenger\MessengerInterface;
use Drupal\node\Entity\Node;
use Drupal\paragraphs\Entity\Paragraph;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\RequestStack;

class MultiStepForm extends FormBase {

  protected $messenger;
  protected $requestStack;

  public function __construct(MessengerInterface $messenger, RequestStack $request_stack) {
    $this->messenger = $messenger;
    $this->requestStack = $request_stack;
  }

  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('messenger'),
      $container->get('request_stack')
    );
  }

  public function getFormId() {
    return 'multi_step_form';
  }

  public function buildForm(array $form, FormStateInterface $form_state) {
    $step = $form_state->get('step');
    if ($step === NULL) {
      $step = 1;
      $form_state->set('step', $step);
    }

    switch ($step) {
      case 1:
        $form = $this->buildStepOne($form, $form_state);
        break;
      case 2:
        $form = $this->buildStepTwo($form, $form_state);
        break;
      case 3:
        $form = $this->buildStepThree($form, $form_state);
        break;
    }

    $form['actions'] = [
      '#type' => 'actions',
    ];

    if ($step > 1) {
      $form['actions']['previous'] = [
        '#type' => 'submit',
        '#value' => $this->t('Previous'),
        '#submit' => ['::submitPrevious'],
        '#limit_validation_errors' => [],
      ];
    }

    if ($step < 3) {
      $form['actions']['next'] = [
        '#type' => 'submit',
        '#value' => $this->t('Next'),
        '#button_type' => 'primary',
        '#submit' => ['::submitNext'],
      ];
    } else {
      $form['actions']['submit'] = [
        '#type' => 'submit',
        '#value' => $this->t('Submit'),
        '#button_type' => 'primary',
      ];
    }

    return $form;
  }

  private function buildStepOne(array &$form, FormStateInterface $form_state) {
    $form['field_first_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('First Name'),
      '#required' => TRUE,
      '#ajax' => [
        'callback' => '::validateFirstNameAjax',
        'wrapper' => 'first-name-message-wrapper',
        'event' => 'change',
      ],
    ];

    $form['first_name_message'] = [
      '#type' => 'markup',
      '#markup' => '<div id="first-name-message-wrapper"></div>',
    ];

    $form['field_last_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Last Name'),
      '#required' => TRUE,
    ];

    $form['field_email'] = [
      '#type' => 'email',
      '#title' => $this->t('Email'),
      '#required' => TRUE,
    ];

    $form['field_address'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Address'),
      '#required' => TRUE,
    ];

    $form['field_country'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Country'),
      '#required' => TRUE,
      '#autocomplete_route_name' => 'multi_step_form.autocomplete_country',
    ];

    $form['field_state'] = [
      '#type' => 'textfield',
      '#title' => $this->t('State'),
      '#required' => TRUE,
    ];

    $form['field_city'] = [
      '#type' => 'textfield',
      '#title' => $this->t('City'),
      '#required' => TRUE,
    ];

    return $form;
  }

  private function buildStepTwo(array &$form, FormStateInterface $form_state) {
    $form['field_company_name'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Company Name'),
      '#required' => TRUE,
    ];

    $form['field_company_addresses'] = [
      '#type' => 'fieldset',
      '#title' => $this->t('Company Addresses'),
      '#prefix' => '<div id="company-addresses-wrapper">',
      '#suffix' => '</div>',
    ];

    $addresses = $form_state->get('company_address_count');
    if ($addresses === NULL) {
      $addresses = 1;
      $form_state->set('company_address_count', $addresses);
    }

    for ($i = 0; $i < $addresses; $i++) {
      $form['field_company_addresses'][$i]['address'] = [
        '#type' => 'textfield',
        '#title' => $this->t('Address'),
        '#required' => TRUE,
      ];
    }

    $form['field_company_addresses']['add_more'] = [
      '#type' => 'submit',
      '#value' => $this->t('Add more addresses'),
      '#submit' => ['::addMoreAddressSubmit'],
      '#ajax' => [
        'callback' => '::addMoreAddressesAjax',
        'wrapper' => 'company-addresses-wrapper',
      ],
      '#limit_validation_errors' => [],
    ];

    return $form;
  }

  private function buildStepThree(array &$form, FormStateInterface $form_state) {
    $form['field_card_number'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Card Number'),
      '#required' => TRUE,
      '#maxlength' => 16,
      '#attributes' => [
        'placeholder' => $this->t('Enter card number'),
      ],
    ];

    $form['field_expiry_date'] = [
      '#type' => 'textfield',
      '#title' => $this->t('Expiry Date'),
      '#required' => TRUE,
      '#attributes' => [
        'placeholder' => $this->t('MM/YY'),
      ],
    ];

    $form['field_cvv'] = [
      '#type' => 'textfield',
      '#title' => $this->t('CVV'),
      '#required' => TRUE,
      '#maxlength' => 4,
      '#attributes' => [
        'placeholder' => $this->t('CVV'),
      ],
    ];

    return $form;
  }

  public function validateForm(array &$form, FormStateInterface $form_state) {
    $step = $form_state->get('step');

    if ($step == 1) {
      if (empty($form_state->getValue('field_first_name'))) {
        $form_state->setErrorByName('field_first_name', $this->t('First Name is required.'));
      }
      if (!filter_var($form_state->getValue('field_email'), FILTER_VALIDATE_EMAIL)) {
        $form_state->setErrorByName('field_email', $this->t('Please enter a valid email address.'));
      }
    } elseif ($step == 2) {
      if (empty($form_state->getValue('field_company_name'))) {
        $form_state->setErrorByName('field_company_name', $this->t('Company Name is required.'));
      }
      $addresses = $form_state->getValue('field_company_addresses');
      foreach ($addresses as $key => $address) {
        if (empty($address['address'])) {
          $form_state->setErrorByName("field_company_addresses[$key][address]", $this->t('Company Address is required.'));
        }
      }
    } elseif ($step == 3) {
      if (empty($form_state->getValue('field_card_number'))) {
        $form_state->setErrorByName('field_card_number', $this->t('Card Number is required.'));
      }
      if (empty($form_state->getValue('field_expiry_date'))) {
        $form_state->setErrorByName('field_expiry_date', $this->t('Expiry Date is required.'));
      }
      if (empty($form_state->getValue('field_cvv'))) {
        $form_state->setErrorByName('field_cvv', $this->t('CVV is required.'));
      }
    }
  }

  public function submitNext(array &$form, FormStateInterface $form_state) {
    $step = $form_state->get('step');
    $values = $form_state->getValues();

    $session = $this->requestStack->getCurrentRequest()->getSession();
    $form_data = $session->get('multistep_form_data', []);
    $form_data = array_merge($form_data, $values);
    $session->set('multistep_form_data', $form_data);

    $form_state->set('step', $step + 1);
    $form_state->setRebuild(TRUE);
  }

  public function submitPrevious(array &$form, FormStateInterface $form_state) {
    $step = $form_state->get('step');
    $form_state->set('step', $step - 1);
    $form_state->setRebuild(TRUE);
  }

  public function submitForm(array &$form, FormStateInterface $form_state) {
    $values = $form_state->getValues();
    $session = $this->requestStack->getCurrentRequest()->getSession();
    $form_data = $session->get('multistep_form_data', []);
    $form_data = array_merge($form_data, $values);
    $session->set('multistep_form_data', $form_data);

    // Prepare company addresses.
    $company_addresses = isset($form_data['field_company_addresses']) ? $form_data['field_company_addresses'] : [];
    $company_addresses_prepared = $this->prepareCompanyAddresses($company_addresses);

    // Save the data to a custom content type.
    $node = Node::create([
      'type' => 'user_registration',
      'title' => $form_data['field_first_name'] . ' ' . $form_data['field_last_name'],
      'field_first_name' => $form_data['field_first_name'],
      'field_last_name' => $form_data['field_last_name'],
      'field_email' => $form_data['field_email'],
      'field_address' => $form_data['field_address'],
      'field_country' => $form_data['field_country'],
      'field_state' => $form_data['field_state'],
      'field_city' => $form_data['field_city'],
      'field_company_name' => $form_data['field_company_name'],
      'field_company_addresses' => $company_addresses_prepared,
      'field_card_number' => $form_data['field_card_number'],
      'field_expiry_date' => $form_data['field_expiry_date'],
      'field_cvv' => $form_data['field_cvv'],
    ]);
    $node->save();

    $this->messenger->addMessage($this->t('Your submission has been saved.'));
    $session->remove('multistep_form_data');
  }

  protected function prepareCompanyAddresses(array $addresses = []) {
    $company_addresses = [];
    if (is_array($addresses)) {
      foreach ($addresses as $address) {
        if (isset($address['address'])) {
          $paragraph = Paragraph::create([
            'type' => 'company_address',
            'field_address' => $address['address'],
          ]);
          $paragraph->save();
          $company_addresses[] = ['target_id' => $paragraph->id()];
        }
      }
    }
    return $company_addresses;
  }

  public function addMoreAddressSubmit(array &$form, FormStateInterface $form_state) {
    $company_address_count = $form_state->get('company_address_count');
    $company_address_count++;
    $form_state->set('company_address_count', $company_address_count);
    $form_state->setRebuild(TRUE);
  }

  public function addMoreAddressesAjax(array &$form, FormStateInterface $form_state) {
    return $form['field_company_addresses'];
  }

  /**
   * AJAX callback for the first name field.
   */
  public function validateFirstNameAjax(array &$form, FormStateInterface $form_state) {
    $first_name = $form_state->getValue('field_first_name');

    // Example validation: check if the first name is "Admin".
    if ($first_name === 'Anmol') {
      $response = [
        '#type' => 'markup',
        '#markup' => '<p class="error">' . $this->t('The name "Anmol" is not allowed.') . '</p>',
      ];
      return $response;
    }

    // Clear message if the value is valid.
    $response = [
      '#type' => 'markup',
      '#markup' => '',
    ];
    return $response;
  }
}
